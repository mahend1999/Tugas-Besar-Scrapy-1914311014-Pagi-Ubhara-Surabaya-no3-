import scrapy


class QuotesSpider(scrapy.Spider):
    name = "adam"

    def start_requests(self):
        urls = [
            'https://www.worldnovel.online/novel/god-of-fishing/',
	    'https://www.worldnovel.online/novel/my-disciples-are-all-villains/',
	    'https://www.worldnovel.online/novel/forging-the-path-to-godliness/',
	    'https://www.worldnovel.online/novel/atw-id/',
	    'https://www.worldnovel.online/novel/astral-pet-store/',
            ]
        for url in urls:
            yield scrapy.Request(url=url, callback=self.parse)

    def parse(self, response):
        page = response.url.split("/")[-2]
        filename = f'quotes-{page}.html'
        with open(filename, 'wb') as f:
            f.write(response.body)
        self.log(f'Saved file {filename}')